/**
 * Career Goals Component
 * Track career goals with milestones, linked skills/certifications, and progress.
 */

import { useState, type FormEvent } from 'react';
import { useData } from '@/context/DataContext';
import type { CareerGoal, GoalPriority, GoalStatus, ValidationError } from '@/types';
import { validate, required, getFieldError } from '@/utils/validation';
import {
  Plus, Search, Edit3, Trash2, X, Save,
  Target, CheckCircle2, Circle, ChevronDown,
  ChevronUp, Flag, Calendar,
} from 'lucide-react';

const PRIORITIES: GoalPriority[] = ['Low', 'Medium', 'High', 'Critical'];
const GOAL_STATUSES: GoalStatus[] = ['Not Started', 'In Progress', 'Completed', 'On Hold'];

const PRIORITY_STYLES: Record<GoalPriority, string> = {
  Low: 'bg-slate-100 text-slate-600',
  Medium: 'bg-blue-100 text-blue-700',
  High: 'bg-amber-100 text-amber-700',
  Critical: 'bg-red-100 text-red-700',
};

const STATUS_STYLES: Record<GoalStatus, string> = {
  'Not Started': 'bg-slate-100 text-slate-600',
  'In Progress': 'bg-blue-100 text-blue-700',
  Completed: 'bg-emerald-100 text-emerald-700',
  'On Hold': 'bg-amber-100 text-amber-700',
};

export function CareerGoals() {
  const { goals, addGoal, updateGoal, deleteGoal, toggleMilestone, addMilestone, deleteMilestone, skills, certifications } = useData();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<GoalStatus | ''>('');
  const [expandedGoal, setExpandedGoal] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [newMilestoneGoalId, setNewMilestoneGoalId] = useState<string | null>(null);
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');

  // Form state
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formTargetDate, setFormTargetDate] = useState('');
  const [formPriority, setFormPriority] = useState<GoalPriority>('Medium');
  const [formStatus, setFormStatus] = useState<GoalStatus>('Not Started');
  const [formLinkedSkills, setFormLinkedSkills] = useState<string[]>([]);
  const [formLinkedCerts, setFormLinkedCerts] = useState<string[]>([]);
  const [errors, setErrors] = useState<ValidationError[]>([]);

  // ── Filtering ────────────────────────────────────────────────────

  const filtered = goals
    .filter((g) => {
      if (searchQuery && !g.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterStatus && g.status !== filterStatus) return false;
      return true;
    })
    .sort((a, b) => {
      const priorityOrder: Record<GoalPriority, number> = { Critical: 4, High: 3, Medium: 2, Low: 1 };
      const statusOrder: Record<GoalStatus, number> = { 'In Progress': 4, 'Not Started': 3, 'On Hold': 2, Completed: 1 };
      const diff = statusOrder[b.status] - statusOrder[a.status];
      if (diff !== 0) return diff;
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });

  // ── Form Handling ────────────────────────────────────────────────

  const resetForm = () => {
    setFormTitle('');
    setFormDesc('');
    setFormTargetDate('');
    setFormPriority('Medium');
    setFormStatus('Not Started');
    setFormLinkedSkills([]);
    setFormLinkedCerts([]);
    setErrors([]);
    setShowForm(false);
    setEditingId(null);
  };

  const openEditForm = (goal: CareerGoal) => {
    setFormTitle(goal.title);
    setFormDesc(goal.description);
    setFormTargetDate(goal.targetDate);
    setFormPriority(goal.priority);
    setFormStatus(goal.status);
    setFormLinkedSkills(goal.linkedSkills);
    setFormLinkedCerts(goal.linkedCertifications);
    setEditingId(goal.id);
    setShowForm(true);
    setErrors([]);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(
      required('title', formTitle),
      required('description', formDesc)
    );
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const goalData = {
      title: formTitle.trim(),
      description: formDesc.trim(),
      targetDate: formTargetDate,
      priority: formPriority,
      status: formStatus,
      milestones: editingId ? (goals.find((g) => g.id === editingId)?.milestones || []) : [],
      linkedSkills: formLinkedSkills,
      linkedCertifications: formLinkedCerts,
    };

    if (editingId) {
      updateGoal(editingId, goalData);
    } else {
      addGoal(goalData);
    }
    resetForm();
  };

  const handleAddMilestone = (goalId: string) => {
    if (!newMilestoneTitle.trim()) return;
    addMilestone(goalId, newMilestoneTitle.trim());
    setNewMilestoneTitle('');
    setNewMilestoneGoalId(null);
  };

  const getGoalProgress = (goal: CareerGoal) => {
    if (goal.milestones.length === 0) return goal.status === 'Completed' ? 100 : 0;
    return Math.round((goal.milestones.filter((m) => m.completed).length / goal.milestones.length) * 100);
  };

  const toggleLinkedSkill = (skillId: string) => {
    setFormLinkedSkills((prev) =>
      prev.includes(skillId) ? prev.filter((id) => id !== skillId) : [...prev, skillId]
    );
  };

  const toggleLinkedCert = (certId: string) => {
    setFormLinkedCerts((prev) =>
      prev.includes(certId) ? prev.filter((id) => id !== certId) : [...prev, certId]
    );
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Career Goals</h1>
          <p className="text-slate-500 mt-1">
            {goals.filter((g) => g.status === 'Completed').length} of {goals.length} goal{goals.length !== 1 ? 's' : ''} completed
          </p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all"
        >
          <Plus className="h-5 w-5" /> Add Goal
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search goals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {GOAL_STATUSES.map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(filterStatus === status ? '' : status)}
              className={`text-xs px-3 py-2 rounded-xl font-medium transition-all ${
                filterStatus === status ? STATUS_STYLES[status] : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={resetForm}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-slate-100 sticky top-0 bg-white rounded-t-2xl z-10">
              <h2 className="text-lg font-semibold text-slate-900">{editingId ? 'Edit Goal' : 'Add New Goal'}</h2>
              <button onClick={resetForm} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Goal Title *</label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., Become a Senior Developer"
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                    getFieldError(errors, 'title') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'title') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'title')}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Description *</label>
                <textarea
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Describe what you want to achieve..."
                  rows={3}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 resize-none transition-all ${
                    getFieldError(errors, 'description') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'description') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'description')}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Target Date</label>
                  <input
                    type="date"
                    value={formTargetDate}
                    onChange={(e) => setFormTargetDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Priority</label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as GoalPriority)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
                  >
                    {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as GoalStatus)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
                >
                  {GOAL_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              {/* Linked Skills */}
              {skills.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Linked Skills</label>
                  <div className="flex flex-wrap gap-2 p-3 rounded-xl border border-slate-200 max-h-32 overflow-y-auto">
                    {skills.map((skill) => (
                      <button
                        key={skill.id}
                        type="button"
                        onClick={() => toggleLinkedSkill(skill.id)}
                        className={`text-xs px-2.5 py-1 rounded-full transition-all ${
                          formLinkedSkills.includes(skill.id)
                            ? 'bg-indigo-100 text-indigo-700 font-medium'
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {skill.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Linked Certifications */}
              {certifications.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Linked Certifications</label>
                  <div className="flex flex-wrap gap-2 p-3 rounded-xl border border-slate-200 max-h-32 overflow-y-auto">
                    {certifications.map((cert) => (
                      <button
                        key={cert.id}
                        type="button"
                        onClick={() => toggleLinkedCert(cert.id)}
                        className={`text-xs px-2.5 py-1 rounded-full transition-all ${
                          formLinkedCerts.includes(cert.id)
                            ? 'bg-violet-100 text-violet-700 font-medium'
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {cert.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button type="button" onClick={resetForm} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-sm font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2">
                  <Save className="h-4 w-4" /> {editingId ? 'Update' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Delete Goal?</h3>
            <p className="text-sm text-slate-500 mb-6">This will also delete all associated milestones.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">Cancel</button>
              <button onClick={() => { deleteGoal(deleteConfirm); setDeleteConfirm(null); }} className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-sm font-medium hover:bg-red-500 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Goals List */}
      {filtered.length > 0 ? (
        <div className="space-y-4">
          {filtered.map((goal) => {
            const progress = getGoalProgress(goal);
            const isExpanded = expandedGoal === goal.id;
            const linkedSkillNames = goal.linkedSkills.map((id) => skills.find((s) => s.id === id)?.name).filter(Boolean);
            const linkedCertNames = goal.linkedCertifications.map((id) => certifications.find((c) => c.id === id)?.name).filter(Boolean);

            return (
              <div key={goal.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all">
                {/* Goal Header */}
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => setExpandedGoal(isExpanded ? null : goal.id)}
                      className="p-1 mt-0.5 hover:bg-slate-100 rounded-lg transition-colors flex-shrink-0"
                    >
                      {isExpanded ? <ChevronUp className="h-5 w-5 text-slate-400" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-2 flex-wrap">
                        <h3 className="font-semibold text-slate-900">{goal.title}</h3>
                        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${PRIORITY_STYLES[goal.priority]}`}>
                          <Flag className="h-3 w-3 inline mr-0.5" />{goal.priority}
                        </span>
                        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${STATUS_STYLES[goal.status]}`}>
                          {goal.status}
                        </span>
                      </div>
                      <p className="text-sm text-slate-500 mt-1 line-clamp-2">{goal.description}</p>

                      {/* Progress bar */}
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                          <span>{goal.milestones.filter((m) => m.completed).length}/{goal.milestones.length} milestones</span>
                          <span className="font-medium">{progress}%</span>
                        </div>
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${goal.status === 'Completed' ? 'bg-emerald-500' : 'bg-gradient-to-r from-indigo-500 to-violet-500'}`}
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>

                      {/* Meta info */}
                      <div className="flex flex-wrap gap-3 mt-3 text-xs text-slate-400">
                        {goal.targetDate && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Target: {new Date(goal.targetDate).toLocaleDateString()}
                          </span>
                        )}
                        {linkedSkillNames.length > 0 && (
                          <span>{linkedSkillNames.length} linked skill{linkedSkillNames.length > 1 ? 's' : ''}</span>
                        )}
                        {linkedCertNames.length > 0 && (
                          <span>{linkedCertNames.length} linked cert{linkedCertNames.length > 1 ? 's' : ''}</span>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-1 flex-shrink-0">
                      <button onClick={() => openEditForm(goal)} className="p-2 rounded-lg hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 transition-colors" title="Edit">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button onClick={() => setDeleteConfirm(goal.id)} className="p-2 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors" title="Delete">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded: Milestones */}
                {isExpanded && (
                  <div className="px-5 pb-5 border-t border-slate-100 pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold text-slate-700">Milestones</h4>
                      <button
                        onClick={() => setNewMilestoneGoalId(newMilestoneGoalId === goal.id ? null : goal.id)}
                        className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
                      >
                        <Plus className="h-3 w-3" /> Add
                      </button>
                    </div>

                    {/* Add milestone input */}
                    {newMilestoneGoalId === goal.id && (
                      <div className="flex gap-2 mb-3">
                        <input
                          type="text"
                          value={newMilestoneTitle}
                          onChange={(e) => setNewMilestoneTitle(e.target.value)}
                          placeholder="Milestone title..."
                          className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddMilestone(goal.id);
                            }
                          }}
                          autoFocus
                        />
                        <button
                          onClick={() => handleAddMilestone(goal.id)}
                          className="px-3 py-2 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-500 transition-colors"
                        >
                          Add
                        </button>
                      </div>
                    )}

                    {goal.milestones.length > 0 ? (
                      <div className="space-y-2">
                        {goal.milestones.map((milestone) => (
                          <div key={milestone.id} className="flex items-center gap-3 group/m">
                            <button
                              onClick={() => toggleMilestone(goal.id, milestone.id)}
                              className="flex-shrink-0"
                            >
                              {milestone.completed ? (
                                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                              ) : (
                                <Circle className="h-5 w-5 text-slate-300 hover:text-indigo-400 transition-colors" />
                              )}
                            </button>
                            <span className={`flex-1 text-sm ${milestone.completed ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                              {milestone.title}
                            </span>
                            {milestone.completedAt && (
                              <span className="text-xs text-slate-400">
                                {new Date(milestone.completedAt).toLocaleDateString()}
                              </span>
                            )}
                            <button
                              onClick={() => deleteMilestone(goal.id, milestone.id)}
                              className="opacity-0 group-hover/m:opacity-100 p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-500 transition-all"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-400 text-center py-4">No milestones yet. Add one to track progress.</p>
                    )}

                    {/* Linked items */}
                    {(linkedSkillNames.length > 0 || linkedCertNames.length > 0) && (
                      <div className="mt-4 pt-4 border-t border-slate-100">
                        {linkedSkillNames.length > 0 && (
                          <div className="mb-2">
                            <span className="text-xs font-medium text-slate-500">Linked Skills:</span>
                            <div className="flex flex-wrap gap-1.5 mt-1">
                              {linkedSkillNames.map((name) => (
                                <span key={name} className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600">{name}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {linkedCertNames.length > 0 && (
                          <div>
                            <span className="text-xs font-medium text-slate-500">Linked Certifications:</span>
                            <div className="flex flex-wrap gap-1.5 mt-1">
                              {linkedCertNames.map((name) => (
                                <span key={name} className="text-xs px-2 py-0.5 rounded-full bg-violet-50 text-violet-600">{name}</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm">
          <Target className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-900 mb-1">
            {goals.length === 0 ? 'No career goals yet' : 'No matching goals'}
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            {goals.length === 0
              ? 'Set your first career goal and start tracking your progress.'
              : 'Try adjusting your search or filters.'}
          </p>
          {goals.length === 0 && (
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500 transition-colors"
            >
              <Plus className="h-4 w-4" /> Set Your First Goal
            </button>
          )}
        </div>
      )}
    </div>
  );
}
