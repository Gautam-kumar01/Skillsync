/**
 * Certifications Component
 * Full CRUD for managing certifications with status tracking and expiry alerts.
 */

import { useState, type FormEvent } from 'react';
import { useData } from '@/context/DataContext';
import type { Certification, CertificationStatus, ValidationError } from '@/types';
import { validate, required, validDate, validUrl, getFieldError } from '@/utils/validation';
import {
  Plus, Search, Edit3, Trash2, X, Save,
  Award, ExternalLink, AlertTriangle, CheckCircle2,
  Clock, CalendarDays,
} from 'lucide-react';

const STATUSES: CertificationStatus[] = ['Active', 'In Progress', 'Planned', 'Expired'];

const STATUS_STYLES: Record<CertificationStatus, { bg: string; text: string; icon: typeof CheckCircle2 }> = {
  Active: { bg: 'bg-emerald-100', text: 'text-emerald-700', icon: CheckCircle2 },
  Expired: { bg: 'bg-red-100', text: 'text-red-700', icon: AlertTriangle },
  'In Progress': { bg: 'bg-blue-100', text: 'text-blue-700', icon: Clock },
  Planned: { bg: 'bg-slate-100', text: 'text-slate-700', icon: CalendarDays },
};

export function Certifications() {
  const { certifications, addCertification, updateCertification, deleteCertification } = useData();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<CertificationStatus | ''>('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formOrg, setFormOrg] = useState('');
  const [formIssueDate, setFormIssueDate] = useState('');
  const [formExpiryDate, setFormExpiryDate] = useState('');
  const [formCredentialId, setFormCredentialId] = useState('');
  const [formCredentialUrl, setFormCredentialUrl] = useState('');
  const [formStatus, setFormStatus] = useState<CertificationStatus>('Active');
  const [formNotes, setFormNotes] = useState('');
  const [errors, setErrors] = useState<ValidationError[]>([]);

  // ── Filtering ────────────────────────────────────────────────────

  const filtered = certifications
    .filter((c) => {
      if (searchQuery && !c.name.toLowerCase().includes(searchQuery.toLowerCase()) && !c.issuingOrganization.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterStatus && c.status !== filterStatus) return false;
      return true;
    })
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  // ── Form Handling ────────────────────────────────────────────────

  const resetForm = () => {
    setFormName('');
    setFormOrg('');
    setFormIssueDate('');
    setFormExpiryDate('');
    setFormCredentialId('');
    setFormCredentialUrl('');
    setFormStatus('Active');
    setFormNotes('');
    setErrors([]);
    setShowForm(false);
    setEditingId(null);
  };

  const openEditForm = (cert: Certification) => {
    setFormName(cert.name);
    setFormOrg(cert.issuingOrganization);
    setFormIssueDate(cert.issueDate);
    setFormExpiryDate(cert.expiryDate);
    setFormCredentialId(cert.credentialId);
    setFormCredentialUrl(cert.credentialUrl);
    setFormStatus(cert.status);
    setFormNotes(cert.notes);
    setEditingId(cert.id);
    setShowForm(true);
    setErrors([]);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(
      required('name', formName),
      required('issuingOrganization', formOrg),
      validDate('issueDate', formIssueDate),
      validDate('expiryDate', formExpiryDate),
      validUrl('credentialUrl', formCredentialUrl)
    );
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const data = {
      name: formName.trim(),
      issuingOrganization: formOrg.trim(),
      issueDate: formIssueDate,
      expiryDate: formExpiryDate,
      credentialId: formCredentialId.trim(),
      credentialUrl: formCredentialUrl.trim(),
      status: formStatus,
      notes: formNotes.trim(),
    };

    if (editingId) {
      updateCertification(editingId, data);
    } else {
      addCertification(data);
    }
    resetForm();
  };

  /**
   * Calculate days until expiry for display.
   */
  const getDaysUntilExpiry = (expiryDate: string): number | null => {
    if (!expiryDate) return null;
    const days = Math.ceil((new Date(expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    return days;
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Certifications</h1>
          <p className="text-slate-500 mt-1">{certifications.length} certification{certifications.length !== 1 ? 's' : ''} tracked</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all"
        >
          <Plus className="h-5 w-5" /> Add Certification
        </button>
      </div>

      {/* Search & Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search certifications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
          />
        </div>
        <div className="flex gap-2">
          {STATUSES.map((status) => {
            const style = STATUS_STYLES[status];
            const count = certifications.filter((c) => c.status === status).length;
            return (
              <button
                key={status}
                onClick={() => setFilterStatus(filterStatus === status ? '' : status)}
                className={`text-xs px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  filterStatus === status ? `${style.bg} ${style.text}` : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                }`}
              >
                {status} <span className="text-[10px] font-bold">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={resetForm}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-slate-100 sticky top-0 bg-white rounded-t-2xl z-10">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingId ? 'Edit Certification' : 'Add New Certification'}
              </h2>
              <button onClick={resetForm} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Certification Name *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g., AWS Solutions Architect"
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                    getFieldError(errors, 'name') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'name') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'name')}</p>}
              </div>

              {/* Organization */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Issuing Organization *</label>
                <input
                  type="text"
                  value={formOrg}
                  onChange={(e) => setFormOrg(e.target.value)}
                  placeholder="e.g., Amazon Web Services"
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                    getFieldError(errors, 'issuingOrganization') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'issuingOrganization') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'issuingOrganization')}</p>}
              </div>

              {/* Status */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as CertificationStatus)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
                >
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Issue Date</label>
                  <input
                    type="date"
                    value={formIssueDate}
                    onChange={(e) => setFormIssueDate(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                      getFieldError(errors, 'issueDate') ? 'border-red-300' : 'border-slate-200'
                    }`}
                  />
                  {getFieldError(errors, 'issueDate') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'issueDate')}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Expiry Date</label>
                  <input
                    type="date"
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                      getFieldError(errors, 'expiryDate') ? 'border-red-300' : 'border-slate-200'
                    }`}
                  />
                  {getFieldError(errors, 'expiryDate') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'expiryDate')}</p>}
                </div>
              </div>

              {/* Credential ID & URL */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Credential ID</label>
                <input
                  type="text"
                  value={formCredentialId}
                  onChange={(e) => setFormCredentialId(e.target.value)}
                  placeholder="e.g., ABC-123-XYZ"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Credential URL</label>
                <input
                  type="url"
                  value={formCredentialUrl}
                  onChange={(e) => setFormCredentialUrl(e.target.value)}
                  placeholder="https://..."
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                    getFieldError(errors, 'credentialUrl') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'credentialUrl') && <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'credentialUrl')}</p>}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes</label>
                <textarea
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Study resources, exam tips, renewal reminders..."
                  rows={3}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 resize-none transition-all"
                />
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={resetForm} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-sm font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2">
                  <Save className="h-4 w-4" /> {editingId ? 'Update' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Delete Certification?</h3>
            <p className="text-sm text-slate-500 mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">Cancel</button>
              <button onClick={() => { deleteCertification(deleteConfirm); setDeleteConfirm(null); }} className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-sm font-medium hover:bg-red-500 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Certifications List */}
      {filtered.length > 0 ? (
        <div className="space-y-4">
          {filtered.map((cert) => {
            const statusStyle = STATUS_STYLES[cert.status];
            const StatusIcon = statusStyle.icon;
            const daysLeft = getDaysUntilExpiry(cert.expiryDate);
            const isExpiringSoon = daysLeft !== null && daysLeft > 0 && daysLeft <= 30;

            return (
              <div key={cert.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all group">
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  {/* Icon & Info */}
                  <div className={`h-12 w-12 rounded-xl ${statusStyle.bg} flex items-center justify-center flex-shrink-0`}>
                    <StatusIcon className={`h-6 w-6 ${statusStyle.text}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-2 flex-wrap">
                      <h3 className="font-semibold text-slate-900">{cert.name}</h3>
                      <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${statusStyle.bg} ${statusStyle.text}`}>
                        {cert.status}
                      </span>
                      {isExpiringSoon && (
                        <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-700 flex items-center gap-1">
                          <AlertTriangle className="h-3 w-3" /> Expires in {daysLeft}d
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-500 mt-0.5">{cert.issuingOrganization}</p>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-slate-400">
                      {cert.issueDate && (
                        <span>Issued: {new Date(cert.issueDate).toLocaleDateString()}</span>
                      )}
                      {cert.expiryDate && (
                        <span>Expires: {new Date(cert.expiryDate).toLocaleDateString()}</span>
                      )}
                      {cert.credentialId && (
                        <span>ID: {cert.credentialId}</span>
                      )}
                    </div>
                    {cert.notes && (
                      <p className="text-sm text-slate-500 mt-2 line-clamp-2">{cert.notes}</p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity flex-shrink-0">
                    {cert.credentialUrl && (
                      <a
                        href={cert.credentialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 transition-colors"
                        title="View Credential"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    )}
                    <button
                      onClick={() => openEditForm(cert)}
                      className="p-2 rounded-lg hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 transition-colors"
                      title="Edit"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(cert.id)}
                      className="p-2 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm">
          <Award className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-900 mb-1">
            {certifications.length === 0 ? 'No certifications yet' : 'No matching certifications'}
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            {certifications.length === 0
              ? 'Add your first certification to start tracking.'
              : 'Try adjusting your search or filters.'}
          </p>
          {certifications.length === 0 && (
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500 transition-colors"
            >
              <Plus className="h-4 w-4" /> Add Your First Certification
            </button>
          )}
        </div>
      )}
    </div>
  );
}
