/**
 * Authentication Component
 * Handles both Login and Registration flows with form validation.
 */

import { useState, type FormEvent } from 'react';
import { useAuth } from '@/context/AuthContext';
import type { ValidationError } from '@/types';
import { getFieldError } from '@/utils/validation';
import { LogIn, UserPlus, Zap, Target, Award, TrendingUp } from 'lucide-react';

export function Auth() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [successMsg, setSuccessMsg] = useState('');
  const { login, register } = useAuth();

  /**
   * Handles form submission for both login and registration.
   */
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setErrors([]);
    setSuccessMsg('');

    let result: ValidationError[];
    if (mode === 'login') {
      result = login(email, password);
    } else {
      result = register(name, email, password);
    }

    if (result.length > 0) {
      setErrors(result);
    }
  };

  /**
   * Toggle between login and registration modes.
   */
  const toggleMode = () => {
    setMode((prev) => (prev === 'login' ? 'register' : 'login'));
    setErrors([]);
    setSuccessMsg('');
    setName('');
    setEmail('');
    setPassword('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center px-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-violet-600/20" />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Zap className="h-7 w-7 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tight">SkillSync</h1>
          </div>
          <p className="text-xl text-indigo-200 mb-12 max-w-md leading-relaxed">
            Track your skills, certifications, and career growth — all in one powerful dashboard.
          </p>

          <div className="space-y-6">
            {[
              { icon: Target, title: 'Track Skills', desc: 'Monitor proficiency across categories' },
              { icon: Award, title: 'Manage Certifications', desc: 'Never miss an expiry date' },
              { icon: TrendingUp, title: 'Career Growth', desc: 'Set goals and track milestones' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Icon className="h-5 w-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">{title}</h3>
                  <p className="text-indigo-300 text-sm">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          {/* Mobile branding */}
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">SkillSync</h1>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            <h2 className="text-2xl font-bold text-white mb-1">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </h2>
            <p className="text-slate-400 mb-8">
              {mode === 'login'
                ? 'Sign in to continue tracking your progress'
                : 'Start your career growth journey today'}
            </p>

            {successMsg && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm">
                {successMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Name field (registration only) */}
              {mode === 'register' && (
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-1.5">
                    Full Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    className={`w-full px-4 py-3 rounded-xl bg-white/5 border text-white placeholder-slate-500 outline-none transition-all focus:ring-2 focus:ring-indigo-500/40 ${
                      getFieldError(errors, 'name') ? 'border-red-500/50' : 'border-white/10'
                    }`}
                  />
                  {getFieldError(errors, 'name') && (
                    <p className="mt-1.5 text-sm text-red-400">{getFieldError(errors, 'name')}</p>
                  )}
                </div>
              )}

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1.5">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border text-white placeholder-slate-500 outline-none transition-all focus:ring-2 focus:ring-indigo-500/40 ${
                    getFieldError(errors, 'email') ? 'border-red-500/50' : 'border-white/10'
                  }`}
                />
                {getFieldError(errors, 'email') && (
                  <p className="mt-1.5 text-sm text-red-400">{getFieldError(errors, 'email')}</p>
                )}
              </div>

              {/* Password */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-slate-300 mb-1.5">
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={mode === 'register' ? 'Min. 6 characters' : '••••••••'}
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border text-white placeholder-slate-500 outline-none transition-all focus:ring-2 focus:ring-indigo-500/40 ${
                    getFieldError(errors, 'password') ? 'border-red-500/50' : 'border-white/10'
                  }`}
                />
                {getFieldError(errors, 'password') && (
                  <p className="mt-1.5 text-sm text-red-400">{getFieldError(errors, 'password')}</p>
                )}
              </div>

              {/* Submit button */}
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold hover:from-indigo-500 hover:to-violet-500 transition-all shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2"
              >
                {mode === 'login' ? (
                  <>
                    <LogIn className="h-5 w-5" /> Sign In
                  </>
                ) : (
                  <>
                    <UserPlus className="h-5 w-5" /> Create Account
                  </>
                )}
              </button>
            </form>

            {/* Toggle mode */}
            <p className="mt-6 text-center text-slate-400 text-sm">
              {mode === 'login' ? "Don't have an account?" : 'Already have an account?'}{' '}
              <button onClick={toggleMode} className="text-indigo-400 hover:text-indigo-300 font-medium transition-colors">
                {mode === 'login' ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
