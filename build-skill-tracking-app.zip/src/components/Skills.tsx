/**
 * Skills Component
 * Full CRUD management for skills with filtering and sorting.
 */

import { useState, type FormEvent } from 'react';
import { useData } from '@/context/DataContext';
import type { Skill, SkillCategory, ProficiencyLevel, ValidationError } from '@/types';
import { validate, required, inRange, getFieldError } from '@/utils/validation';
import {
  Plus, Search, Edit3, Trash2, X, Save,
  Filter, ArrowUpDown, Brain,
} from 'lucide-react';

const CATEGORIES: SkillCategory[] = ['Technical', 'Soft Skills', 'Leadership', 'Design', 'Data', 'Marketing', 'Finance', 'Other'];
const PROFICIENCIES: ProficiencyLevel[] = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];

const PROFICIENCY_COLORS: Record<ProficiencyLevel, string> = {
  Beginner: 'bg-amber-100 text-amber-700',
  Intermediate: 'bg-blue-100 text-blue-700',
  Advanced: 'bg-violet-100 text-violet-700',
  Expert: 'bg-emerald-100 text-emerald-700',
};

const CATEGORY_COLORS: Record<string, string> = {
  Technical: 'bg-blue-50 text-blue-600',
  'Soft Skills': 'bg-pink-50 text-pink-600',
  Leadership: 'bg-amber-50 text-amber-600',
  Design: 'bg-violet-50 text-violet-600',
  Data: 'bg-cyan-50 text-cyan-600',
  Marketing: 'bg-orange-50 text-orange-600',
  Finance: 'bg-emerald-50 text-emerald-600',
  Other: 'bg-slate-50 text-slate-600',
};

type SortField = 'name' | 'proficiency' | 'progressPercent' | 'updatedAt';

export function Skills() {
  const { skills, addSkill, updateSkill, deleteSkill } = useData();

  // UI State
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<SkillCategory | ''>('');
  const [filterProficiency, setFilterProficiency] = useState<ProficiencyLevel | ''>('');
  const [sortField, setSortField] = useState<SortField>('updatedAt');
  const [sortAsc, setSortAsc] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<SkillCategory>('Technical');
  const [formProficiency, setFormProficiency] = useState<ProficiencyLevel>('Beginner');
  const [formProgress, setFormProgress] = useState(0);
  const [formNotes, setFormNotes] = useState('');
  const [errors, setErrors] = useState<ValidationError[]>([]);

  // ── Filtering & Sorting ──────────────────────────────────────────

  const proficiencyOrder: Record<ProficiencyLevel, number> = { Beginner: 1, Intermediate: 2, Advanced: 3, Expert: 4 };

  const filtered = skills
    .filter((s) => {
      if (searchQuery && !s.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterCategory && s.category !== filterCategory) return false;
      if (filterProficiency && s.proficiency !== filterProficiency) return false;
      return true;
    })
    .sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'proficiency': cmp = proficiencyOrder[a.proficiency] - proficiencyOrder[b.proficiency]; break;
        case 'progressPercent': cmp = a.progressPercent - b.progressPercent; break;
        case 'updatedAt': cmp = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime(); break;
      }
      return sortAsc ? cmp : -cmp;
    });

  // ── Form Handling ────────────────────────────────────────────────

  const resetForm = () => {
    setFormName('');
    setFormCategory('Technical');
    setFormProficiency('Beginner');
    setFormProgress(0);
    setFormNotes('');
    setErrors([]);
    setShowForm(false);
    setEditingId(null);
  };

  const openEditForm = (skill: Skill) => {
    setFormName(skill.name);
    setFormCategory(skill.category);
    setFormProficiency(skill.proficiency);
    setFormProgress(skill.progressPercent);
    setFormNotes(skill.notes);
    setEditingId(skill.id);
    setShowForm(true);
    setErrors([]);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(
      required('name', formName),
      inRange('progress', formProgress, 0, 100)
    );
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const skillData = {
      name: formName.trim(),
      category: formCategory,
      proficiency: formProficiency,
      progressPercent: formProgress,
      notes: formNotes.trim(),
    };

    if (editingId) {
      updateSkill(editingId, skillData);
    } else {
      addSkill(skillData);
    }
    resetForm();
  };

  const handleDelete = (id: string) => {
    deleteSkill(id);
    setDeleteConfirm(null);
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Skills</h1>
          <p className="text-slate-500 mt-1">{skills.length} skill{skills.length !== 1 ? 's' : ''} tracked</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all"
        >
          <Plus className="h-5 w-5" /> Add Skill
        </button>
      </div>

      {/* Search & Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
            />
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value as SkillCategory | '')}
                className="pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
              >
                <option value="">All Categories</option>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <select
              value={filterProficiency}
              onChange={(e) => setFilterProficiency(e.target.value as ProficiencyLevel | '')}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
            >
              <option value="">All Levels</option>
              {PROFICIENCIES.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
        </div>

        {/* Sort buttons */}
        <div className="flex gap-2 mt-3 flex-wrap">
          <span className="text-xs text-slate-500 flex items-center gap-1 mr-1">
            <ArrowUpDown className="h-3 w-3" /> Sort by:
          </span>
          {([
            ['name', 'Name'],
            ['proficiency', 'Level'],
            ['progressPercent', 'Progress'],
            ['updatedAt', 'Updated'],
          ] as [SortField, string][]).map(([field, label]) => (
            <button
              key={field}
              onClick={() => toggleSort(field)}
              className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${
                sortField === field
                  ? 'bg-indigo-100 text-indigo-700 font-medium'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {label} {sortField === field && (sortAsc ? '↑' : '↓')}
            </button>
          ))}
        </div>
      </div>

      {/* Add/Edit Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={resetForm}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-slate-100">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingId ? 'Edit Skill' : 'Add New Skill'}
              </h2>
              <button onClick={resetForm} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Skill Name *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g., React, Python, Public Speaking"
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all ${
                    getFieldError(errors, 'name') ? 'border-red-300' : 'border-slate-200'
                  }`}
                />
                {getFieldError(errors, 'name') && (
                  <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'name')}</p>
                )}
              </div>

              {/* Category & Proficiency */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as SkillCategory)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
                  >
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Proficiency</label>
                  <select
                    value={formProficiency}
                    onChange={(e) => setFormProficiency(e.target.value as ProficiencyLevel)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 appearance-none bg-white cursor-pointer"
                  >
                    {PROFICIENCIES.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>

              {/* Progress */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Progress: {formProgress}%
                </label>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={formProgress}
                  onChange={(e) => setFormProgress(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
                {getFieldError(errors, 'progress') && (
                  <p className="mt-1 text-sm text-red-500">{getFieldError(errors, 'progress')}</p>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes</label>
                <textarea
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Add any notes about your learning journey..."
                  rows={3}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 resize-none transition-all"
                />
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-sm font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2"
                >
                  <Save className="h-4 w-4" />
                  {editingId ? 'Update Skill' : 'Add Skill'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Delete Skill?</h3>
            <p className="text-sm text-slate-500 mb-6">This action cannot be undone. The skill will be permanently removed.</p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-sm font-medium hover:bg-red-500 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Skills Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((skill) => (
            <div
              key={skill.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-slate-900">{skill.name}</h3>
                  <span className={`inline-block text-xs px-2 py-0.5 rounded-full mt-1 ${CATEGORY_COLORS[skill.category] || 'bg-slate-100 text-slate-600'}`}>
                    {skill.category}
                  </span>
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${PROFICIENCY_COLORS[skill.proficiency]}`}>
                  {skill.proficiency}
                </span>
              </div>

              {/* Progress bar */}
              <div className="mb-3">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span>Progress</span>
                  <span className="font-medium">{skill.progressPercent}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all"
                    style={{ width: `${skill.progressPercent}%` }}
                  />
                </div>
              </div>

              {skill.notes && (
                <p className="text-sm text-slate-500 line-clamp-2 mb-3">{skill.notes}</p>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <span className="text-xs text-slate-400">
                  Updated {new Date(skill.updatedAt).toLocaleDateString()}
                </span>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => openEditForm(skill)}
                    className="p-1.5 rounded-lg hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 transition-colors"
                    title="Edit"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(skill.id)}
                    className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm">
          <Brain className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-900 mb-1">
            {skills.length === 0 ? 'No skills yet' : 'No matching skills'}
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            {skills.length === 0
              ? 'Start tracking your skills by adding your first one.'
              : 'Try adjusting your filters or search query.'}
          </p>
          {skills.length === 0 && (
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500 transition-colors"
            >
              <Plus className="h-4 w-4" /> Add Your First Skill
            </button>
          )}
        </div>
      )}
    </div>
  );
}
