/**
 * Local Storage Utility
 * Provides type-safe CRUD operations on localStorage,
 * acting as a lightweight client-side database layer.
 */

const PREFIX = 'skillsync_';

/**
 * Retrieves and parses a value from localStorage.
 */
export function getItem<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    console.error(`Failed to parse localStorage key: ${key}`);
    return null;
  }
}

/**
 * Serializes and stores a value in localStorage.
 */
export function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    console.error(`Failed to write localStorage key: ${key}`);
  }
}

/**
 * Removes a key from localStorage.
 */
export function removeItem(key: string): void {
  localStorage.removeItem(PREFIX + key);
}

/**
 * Retrieves an array from storage, returning empty array if none exists.
 */
export function getCollection<T>(key: string): T[] {
  return getItem<T[]>(key) ?? [];
}

/**
 * Saves a full collection (array) to storage.
 */
export function setCollection<T>(key: string, items: T[]): void {
  setItem(key, items);
}

/**
 * Simple password hashing (base64 encode with salt).
 * NOTE: In production, use bcrypt on a real server.
 * This provides basic obfuscation for localStorage demo.
 */
export function hashPassword(password: string): string {
  const salt = 'skillsync_salt_2024';
  return btoa(salt + password);
}

/**
 * Verify password against stored hash.
 */
export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}
