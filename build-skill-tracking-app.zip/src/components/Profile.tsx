/**
 * Profile Component
 * View and edit user profile information with account statistics.
 */

import { useState, type FormEvent } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import {
  User, Mail, Briefcase, FileText, Save,
  Brain, Award, Target, Calendar, Edit3,
  CheckCircle2, TrendingUp,
} from 'lucide-react';

export function Profile() {
  const { user, updateProfile } = useAuth();
  const { skills, certifications, goals } = useData();

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editBio, setEditBio] = useState(user?.bio || '');
  const [editJobTitle, setEditJobTitle] = useState(user?.jobTitle || '');
  const [saved, setSaved] = useState(false);

  if (!user) return null;

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;

    updateProfile({
      name: editName.trim(),
      bio: editBio.trim(),
      jobTitle: editJobTitle.trim(),
    });
    setIsEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleCancel = () => {
    setEditName(user.name);
    setEditBio(user.bio);
    setEditJobTitle(user.jobTitle);
    setIsEditing(false);
  };

  // ── Statistics ───────────────────────────────────────────────────

  const totalSkills = skills.length;
  const expertSkills = skills.filter((s) => s.proficiency === 'Expert').length;
  const activeCerts = certifications.filter((c) => c.status === 'Active').length;
  const completedGoals = goals.filter((g) => g.status === 'Completed').length;
  const totalMilestones = goals.reduce((sum, g) => sum + g.milestones.length, 0);
  const completedMilestones = goals.reduce((sum, g) => sum + g.milestones.filter((m) => m.completed).length, 0);
  const memberSince = new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Profile</h1>
        <p className="text-slate-500 mt-1">Manage your account information</p>
      </div>

      {/* Success Message */}
      {saved && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">
          <CheckCircle2 className="h-4 w-4" />
          Profile updated successfully!
        </div>
      )}

      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Banner */}
        <div className="h-32 bg-gradient-to-r from-indigo-500 via-violet-500 to-purple-500 relative">
          <div className="absolute -bottom-12 left-6">
            <div className="h-24 w-24 rounded-2xl bg-white border-4 border-white shadow-lg flex items-center justify-center bg-gradient-to-br from-indigo-500 to-violet-600">
              <span className="text-3xl font-bold text-white">{user.avatar}</span>
            </div>
          </div>
        </div>

        <div className="pt-16 px-6 pb-6">
          {isEditing ? (
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  <User className="h-4 w-4 inline mr-1" /> Full Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  <Briefcase className="h-4 w-4 inline mr-1" /> Job Title
                </label>
                <input
                  type="text"
                  value={editJobTitle}
                  onChange={(e) => setEditJobTitle(e.target.value)}
                  placeholder="e.g., Senior Software Engineer"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  <FileText className="h-4 w-4 inline mr-1" /> Bio
                </label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Tell us about yourself..."
                  rows={4}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-300 resize-none transition-all"
                />
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-sm font-medium hover:from-indigo-500 hover:to-violet-500 shadow-lg shadow-indigo-500/25 transition-all flex items-center gap-2"
                >
                  <Save className="h-4 w-4" /> Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{user.name}</h2>
                  {user.jobTitle && (
                    <p className="text-sm text-indigo-600 font-medium mt-0.5">{user.jobTitle}</p>
                  )}
                  <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                    <Mail className="h-3.5 w-3.5" /> {user.email}
                  </p>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                    <Calendar className="h-3 w-3" /> Member since {memberSince}
                  </p>
                </div>
                <button
                  onClick={() => setIsEditing(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  <Edit3 className="h-4 w-4" /> Edit
                </button>
              </div>
              {user.bio && (
                <p className="text-sm text-slate-600 mt-4 leading-relaxed">{user.bio}</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Brain, label: 'Skills', value: totalSkills, sub: `${expertSkills} expert`, color: 'from-indigo-500 to-indigo-600' },
          { icon: Award, label: 'Certifications', value: certifications.length, sub: `${activeCerts} active`, color: 'from-violet-500 to-violet-600' },
          { icon: Target, label: 'Goals', value: goals.length, sub: `${completedGoals} completed`, color: 'from-emerald-500 to-emerald-600' },
          { icon: TrendingUp, label: 'Milestones', value: totalMilestones, sub: `${completedMilestones} done`, color: 'from-amber-500 to-amber-600' },
        ].map((stat) => (
          <div key={stat.label} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
            <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="h-5 w-5 text-white" />
            </div>
            <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
            <p className="text-sm text-slate-500">{stat.label}</p>
            <p className="text-xs text-slate-400 mt-0.5">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Top Skills */}
      {skills.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Top Skills</h3>
          <div className="space-y-3">
            {[...skills]
              .sort((a, b) => b.progressPercent - a.progressPercent)
              .slice(0, 5)
              .map((skill) => (
                <div key={skill.id} className="flex items-center gap-4">
                  <span className="text-sm font-medium text-slate-700 w-40 truncate">{skill.name}</span>
                  <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all"
                      style={{ width: `${skill.progressPercent}%` }}
                    />
                  </div>
                  <span className="text-sm font-semibold text-slate-900 w-12 text-right">{skill.progressPercent}%</span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Account Info */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Account Information</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">User ID</p>
            <p className="text-sm text-slate-700 mt-1 font-mono truncate">{user.id}</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Email</p>
            <p className="text-sm text-slate-700 mt-1">{user.email}</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Member Since</p>
            <p className="text-sm text-slate-700 mt-1">{memberSince}</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Data Storage</p>
            <p className="text-sm text-slate-700 mt-1">Local (Browser)</p>
          </div>
        </div>
      </div>
    </div>
  );
}
