/**
 * SkillSync Type Definitions
 * Central type definitions for the entire application.
 */

// ── User & Authentication ──────────────────────────────────────────────

export interface User {
  id: string;
  email: string;
  name: string;
  passwordHash: string; // bcrypt-style hash stored locally
  avatar: string; // initials-based
  createdAt: string;
  bio: string;
  jobTitle: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

// ── Skills ─────────────────────────────────────────────────────────────

export type SkillCategory =
  | 'Technical'
  | 'Soft Skills'
  | 'Leadership'
  | 'Design'
  | 'Data'
  | 'Marketing'
  | 'Finance'
  | 'Other';

export type ProficiencyLevel =
  | 'Beginner'
  | 'Intermediate'
  | 'Advanced'
  | 'Expert';

export interface Skill {
  id: string;
  userId: string;
  name: string;
  category: SkillCategory;
  proficiency: ProficiencyLevel;
  progressPercent: number; // 0-100
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// ── Certifications ─────────────────────────────────────────────────────

export type CertificationStatus = 'Active' | 'Expired' | 'In Progress' | 'Planned';

export interface Certification {
  id: string;
  userId: string;
  name: string;
  issuingOrganization: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  credentialUrl: string;
  status: CertificationStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

// ── Career Goals ───────────────────────────────────────────────────────

export type GoalPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type GoalStatus = 'Not Started' | 'In Progress' | 'Completed' | 'On Hold';

export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  completedAt: string | null;
}

export interface CareerGoal {
  id: string;
  userId: string;
  title: string;
  description: string;
  targetDate: string;
  priority: GoalPriority;
  status: GoalStatus;
  milestones: Milestone[];
  linkedSkills: string[]; // Skill IDs
  linkedCertifications: string[]; // Certification IDs
  createdAt: string;
  updatedAt: string;
}

// ── Form Validation ────────────────────────────────────────────────────

export interface ValidationError {
  field: string;
  message: string;
}

// ── App Pages ──────────────────────────────────────────────────────────

export type Page =
  | 'dashboard'
  | 'skills'
  | 'certifications'
  | 'goals'
  | 'profile';
