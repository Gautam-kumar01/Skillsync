/**
 * Authentication Context
 * Manages user registration, login, logout, and profile updates.
 * Uses localStorage to persist user sessions.
 */

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { v4 as uuid } from 'uuid';
import type { User, ValidationError } from '@/types';
import { getCollection, setCollection, getItem, setItem, removeItem, hashPassword, verifyPassword } from '@/utils/storage';
import { validate, required, validEmail, minLength } from '@/utils/validation';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => ValidationError[];
  register: (name: string, email: string, password: string) => ValidationError[];
  logout: () => void;
  updateProfile: (updates: Partial<Pick<User, 'name' | 'bio' | 'jobTitle'>>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

/**
 * Generates initials from a user's full name.
 */
function getInitials(name: string): string {
  return name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  // Restore session from localStorage on mount
  const [user, setUser] = useState<User | null>(() => {
    return getItem<User>('current_user');
  });

  /**
   * Authenticate an existing user with email and password.
   * Returns an array of validation errors (empty if successful).
   */
  const login = useCallback((email: string, password: string): ValidationError[] => {
    // Client-side validation
    const errors = validate(
      required('email', email),
      validEmail('email', email),
      required('password', password)
    );
    if (errors.length > 0) return errors;

    // Look up user in storage
    const users = getCollection<User>('users');
    const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());

    if (!found) {
      return [{ field: 'email', message: 'No account found with this email address' }];
    }

    if (!verifyPassword(password, found.passwordHash)) {
      return [{ field: 'password', message: 'Incorrect password' }];
    }

    // Set session
    setItem('current_user', found);
    setUser(found);
    return [];
  }, []);

  /**
   * Register a new user account.
   * Returns an array of validation errors (empty if successful).
   */
  const register = useCallback((name: string, email: string, password: string): ValidationError[] => {
    // Client-side validation
    const errors = validate(
      required('name', name),
      minLength('name', name, 2),
      required('email', email),
      validEmail('email', email),
      required('password', password),
      minLength('password', password, 6)
    );
    if (errors.length > 0) return errors;

    // Check for duplicate email
    const users = getCollection<User>('users');
    const exists = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      return [{ field: 'email', message: 'An account with this email already exists' }];
    }

    // Create new user
    const newUser: User = {
      id: uuid(),
      email: email.toLowerCase().trim(),
      name: name.trim(),
      passwordHash: hashPassword(password),
      avatar: getInitials(name),
      createdAt: new Date().toISOString(),
      bio: '',
      jobTitle: '',
    };

    // Persist user to storage
    users.push(newUser);
    setCollection('users', users);
    setItem('current_user', newUser);
    setUser(newUser);
    return [];
  }, []);

  /**
   * Log out the current user and clear the session.
   */
  const logout = useCallback(() => {
    removeItem('current_user');
    setUser(null);
  }, []);

  /**
   * Update the current user's profile fields.
   */
  const updateProfile = useCallback((updates: Partial<Pick<User, 'name' | 'bio' | 'jobTitle'>>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const updated: User = {
        ...prev,
        ...updates,
        avatar: updates.name ? getInitials(updates.name) : prev.avatar,
      };
      // Update in users collection
      const users = getCollection<User>('users');
      const idx = users.findIndex((u) => u.id === prev.id);
      if (idx !== -1) {
        users[idx] = updated;
        setCollection('users', users);
      }
      setItem('current_user', updated);
      return updated;
    });
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

/**
 * Hook to access authentication state and methods.
 */
export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
