/**
 * Form Validation Utilities
 * Client-side validation with meaningful error messages.
 */

import type { ValidationError } from '@/types';

/**
 * Validates that a string field is not empty.
 */
export function required(field: string, value: string): ValidationError | null {
  if (!value || value.trim().length === 0) {
    return { field, message: `${formatFieldName(field)} is required` };
  }
  return null;
}

/**
 * Validates email format.
 */
export function validEmail(field: string, value: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) {
    return { field, message: 'Please enter a valid email address' };
  }
  return null;
}

/**
 * Validates minimum string length.
 */
export function minLength(field: string, value: string, min: number): ValidationError | null {
  if (value.length < min) {
    return { field, message: `${formatFieldName(field)} must be at least ${min} characters` };
  }
  return null;
}

/**
 * Validates that a number is within a range.
 */
export function inRange(field: string, value: number, min: number, max: number): ValidationError | null {
  if (value < min || value > max) {
    return { field, message: `${formatFieldName(field)} must be between ${min} and ${max}` };
  }
  return null;
}

/**
 * Validates a date string is valid.
 */
export function validDate(field: string, value: string): ValidationError | null {
  if (!value) return null; // Optional date fields
  const date = new Date(value);
  if (isNaN(date.getTime())) {
    return { field, message: `${formatFieldName(field)} must be a valid date` };
  }
  return null;
}

/**
 * Validates a URL string.
 */
export function validUrl(field: string, value: string): ValidationError | null {
  if (!value) return null; // Optional URL fields
  try {
    new URL(value);
    return null;
  } catch {
    return { field, message: `${formatFieldName(field)} must be a valid URL` };
  }
}

/**
 * Runs multiple validators and collects all errors.
 */
export function validate(...checks: (ValidationError | null)[]): ValidationError[] {
  return checks.filter((e): e is ValidationError => e !== null);
}

/**
 * Converts a camelCase field name to a human-readable format.
 */
function formatFieldName(field: string): string {
  return field
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (s) => s.toUpperCase())
    .trim();
}

/**
 * Checks if a specific field has an error.
 */
export function getFieldError(errors: ValidationError[], field: string): string | undefined {
  return errors.find((e) => e.field === field)?.message;
}
