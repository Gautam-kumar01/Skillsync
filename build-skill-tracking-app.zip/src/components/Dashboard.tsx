/**
 * Dashboard Component
 * Overview of skills, certifications, and goals with charts and statistics.
 */

import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import type { Page } from '@/types';
import {
  Brain, Award, Target, TrendingUp,
  ArrowRight, AlertTriangle, CheckCircle2, Clock,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts';

interface DashboardProps {
  onNavigate: (page: Page) => void;
}

/** Color palette for charts */
const CHART_COLORS = ['#6366f1', '#8b5cf6', '#a78bfa', '#c4b5fd', '#818cf8', '#6d28d9'];
const PROFICIENCY_COLORS: Record<string, string> = {
  Beginner: '#f59e0b',
  Intermediate: '#3b82f6',
  Advanced: '#8b5cf6',
  Expert: '#10b981',
};

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuth();
  const { skills, certifications, goals } = useData();

  // ── Computed Statistics ──────────────────────────────────────────

  const totalSkills = skills.length;
  const avgProgress = totalSkills > 0
    ? Math.round(skills.reduce((sum, s) => sum + s.progressPercent, 0) / totalSkills)
    : 0;

  const activeCerts = certifications.filter((c) => c.status === 'Active').length;
  const expiringCerts = certifications.filter((c) => {
    if (c.status !== 'Active' || !c.expiryDate) return false;
    const daysUntilExpiry = (new Date(c.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  });

  const completedGoals = goals.filter((g) => g.status === 'Completed').length;
  const inProgressGoals = goals.filter((g) => g.status === 'In Progress').length;

  // ── Chart Data ─────────────────────────────────────────────────

  /** Skills by category for bar chart */
  const skillsByCategory = skills.reduce<Record<string, number>>((acc, s) => {
    acc[s.category] = (acc[s.category] || 0) + 1;
    return acc;
  }, {});
  const categoryChartData = Object.entries(skillsByCategory).map(([name, count]) => ({ name, count }));

  /** Skills by proficiency for pie chart */
  const skillsByProficiency = skills.reduce<Record<string, number>>((acc, s) => {
    acc[s.proficiency] = (acc[s.proficiency] || 0) + 1;
    return acc;
  }, {});
  const proficiencyChartData = Object.entries(skillsByProficiency).map(([name, value]) => ({ name, value }));

  // ── Recent Activity ────────────────────────────────────────────

  const recentSkills = [...skills].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 5);
  const recentCerts = [...certifications].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
          Welcome back, {user?.name?.split(' ')[0]}! 👋
        </h1>
        <p className="text-slate-500 mt-1">Here's an overview of your career growth.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: 'Total Skills',
            value: totalSkills,
            sub: `${avgProgress}% avg progress`,
            icon: Brain,
            color: 'from-indigo-500 to-indigo-600',
            bgColor: 'bg-indigo-50',
            textColor: 'text-indigo-700',
          },
          {
            label: 'Certifications',
            value: certifications.length,
            sub: `${activeCerts} active`,
            icon: Award,
            color: 'from-violet-500 to-violet-600',
            bgColor: 'bg-violet-50',
            textColor: 'text-violet-700',
          },
          {
            label: 'Career Goals',
            value: goals.length,
            sub: `${completedGoals} completed`,
            icon: Target,
            color: 'from-emerald-500 to-emerald-600',
            bgColor: 'bg-emerald-50',
            textColor: 'text-emerald-700',
          },
          {
            label: 'In Progress',
            value: inProgressGoals,
            sub: 'active goals',
            icon: TrendingUp,
            color: 'from-amber-500 to-amber-600',
            bgColor: 'bg-amber-50',
            textColor: 'text-amber-700',
          },
        ].map((stat) => (
          <div key={stat.label} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-slate-900 mt-1">{stat.value}</p>
                <p className={`text-xs mt-1 ${stat.textColor}`}>{stat.sub}</p>
              </div>
              <div className={`h-11 w-11 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-sm`}>
                <stat.icon className="h-5 w-5 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Expiring Certifications Warning */}
      {expiringCerts.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800">
              {expiringCerts.length} certification{expiringCerts.length > 1 ? 's' : ''} expiring soon
            </p>
            <p className="text-sm text-amber-700 mt-1">
              {expiringCerts.map((c) => c.name).join(', ')} — expiring within 30 days.
            </p>
            <button
              onClick={() => onNavigate('certifications')}
              className="text-sm text-amber-800 font-medium mt-2 hover:underline flex items-center gap-1"
            >
              View Details <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Skills by Category */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Skills by Category</h3>
          {categoryChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={categoryChartData}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="count" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-slate-400">
              <div className="text-center">
                <Brain className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Add skills to see category breakdown</p>
              </div>
            </div>
          )}
        </div>

        {/* Skills by Proficiency */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Proficiency Distribution</h3>
          {proficiencyChartData.length > 0 ? (
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={proficiencyChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {proficiencyChartData.map((entry, i) => (
                      <Cell key={entry.name} fill={PROFICIENCY_COLORS[entry.name] || CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 flex-shrink-0">
                {proficiencyChartData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: PROFICIENCY_COLORS[entry.name] || '#6366f1' }}
                    />
                    <span className="text-sm text-slate-600">{entry.name}</span>
                    <span className="text-sm font-semibold text-slate-900">{entry.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-slate-400">
              <div className="text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Add skills to see proficiency distribution</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Skills */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">Recent Skills</h3>
            <button
              onClick={() => onNavigate('skills')}
              className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
            >
              View All <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {recentSkills.length > 0 ? (
            <div className="space-y-3">
              {recentSkills.map((skill) => (
                <div key={skill.id} className="flex items-center gap-3">
                  <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: PROFICIENCY_COLORS[skill.proficiency] }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{skill.name}</p>
                    <p className="text-xs text-slate-500">{skill.category} · {skill.proficiency}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-indigo-500 transition-all"
                        style={{ width: `${skill.progressPercent}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-500 w-8 text-right">{skill.progressPercent}%</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400 text-center py-8">No skills added yet</p>
          )}
        </div>

        {/* Recent Certifications */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">Certifications</h3>
            <button
              onClick={() => onNavigate('certifications')}
              className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
            >
              View All <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {recentCerts.length > 0 ? (
            <div className="space-y-3">
              {recentCerts.map((cert) => (
                <div key={cert.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className={`h-9 w-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    cert.status === 'Active' ? 'bg-emerald-100' :
                    cert.status === 'Expired' ? 'bg-red-100' :
                    cert.status === 'In Progress' ? 'bg-blue-100' : 'bg-slate-100'
                  }`}>
                    {cert.status === 'Active' ? <CheckCircle2 className="h-4 w-4 text-emerald-600" /> :
                     cert.status === 'Expired' ? <AlertTriangle className="h-4 w-4 text-red-600" /> :
                     <Clock className="h-4 w-4 text-blue-600" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-slate-900 truncate">{cert.name}</p>
                    <p className="text-xs text-slate-500 truncate">{cert.issuingOrganization}</p>
                  </div>
                  <span className={`text-xs font-medium px-2 py-1 rounded-full flex-shrink-0 ${
                    cert.status === 'Active' ? 'bg-emerald-100 text-emerald-700' :
                    cert.status === 'Expired' ? 'bg-red-100 text-red-700' :
                    cert.status === 'In Progress' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {cert.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-400 text-center py-8">No certifications added yet</p>
          )}
        </div>
      </div>

      {/* Goal Progress */}
      {goals.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">Goal Progress</h3>
            <button
              onClick={() => onNavigate('goals')}
              className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
            >
              View All <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-4">
            {goals.slice(0, 4).map((goal) => {
              const totalMilestones = goal.milestones.length;
              const completedMilestones = goal.milestones.filter((m) => m.completed).length;
              const progress = totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0;
              return (
                <div key={goal.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-slate-900">{goal.title}</span>
                    <span className="text-xs text-slate-500">{progress}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        goal.status === 'Completed' ? 'bg-emerald-500' : 'bg-indigo-500'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs text-slate-400">
                      {completedMilestones}/{totalMilestones} milestones
                    </span>
                    <span className={`text-xs font-medium ${
                      goal.status === 'Completed' ? 'text-emerald-600' :
                      goal.status === 'In Progress' ? 'text-blue-600' :
                      goal.status === 'On Hold' ? 'text-amber-600' : 'text-slate-500'
                    }`}>
                      {goal.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
