/**
 * Data Context
 * Manages all CRUD operations for Skills, Certifications, and Career Goals.
 * Data is scoped per user and persisted to localStorage.
 */

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import { v4 as uuid } from 'uuid';
import type { Skill, Certification, CareerGoal, Milestone } from '@/types';
import { getCollection, setCollection } from '@/utils/storage';
import { useAuth } from './AuthContext';

interface DataContextType {
  // Skills
  skills: Skill[];
  addSkill: (skill: Omit<Skill, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => void;
  updateSkill: (id: string, updates: Partial<Skill>) => void;
  deleteSkill: (id: string) => void;

  // Certifications
  certifications: Certification[];
  addCertification: (cert: Omit<Certification, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => void;
  updateCertification: (id: string, updates: Partial<Certification>) => void;
  deleteCertification: (id: string) => void;

  // Career Goals
  goals: CareerGoal[];
  addGoal: (goal: Omit<CareerGoal, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => void;
  updateGoal: (id: string, updates: Partial<CareerGoal>) => void;
  deleteGoal: (id: string) => void;
  toggleMilestone: (goalId: string, milestoneId: string) => void;
  addMilestone: (goalId: string, title: string) => void;
  deleteMilestone: (goalId: string, milestoneId: string) => void;
}

const DataContext = createContext<DataContextType | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [certifications, setCertifications] = useState<Certification[]>([]);
  const [goals, setGoals] = useState<CareerGoal[]>([]);

  // Load user-specific data when user changes
  useEffect(() => {
    if (user) {
      const allSkills = getCollection<Skill>('skills');
      const allCerts = getCollection<Certification>('certifications');
      const allGoals = getCollection<CareerGoal>('goals');
      setSkills(allSkills.filter((s) => s.userId === user.id));
      setCertifications(allCerts.filter((c) => c.userId === user.id));
      setGoals(allGoals.filter((g) => g.userId === user.id));
    } else {
      setSkills([]);
      setCertifications([]);
      setGoals([]);
    }
  }, [user]);

  /**
   * Helper: persist skills to localStorage after state update.
   */
  const persistSkills = useCallback((updated: Skill[]) => {
    const all = getCollection<Skill>('skills').filter((s) => s.userId !== user?.id);
    setCollection('skills', [...all, ...updated]);
  }, [user]);

  const persistCerts = useCallback((updated: Certification[]) => {
    const all = getCollection<Certification>('certifications').filter((c) => c.userId !== user?.id);
    setCollection('certifications', [...all, ...updated]);
  }, [user]);

  const persistGoals = useCallback((updated: CareerGoal[]) => {
    const all = getCollection<CareerGoal>('goals').filter((g) => g.userId !== user?.id);
    setCollection('goals', [...all, ...updated]);
  }, [user]);

  // ── Skills CRUD ────────────────────────────────────────────────────

  const addSkill = useCallback((skill: Omit<Skill, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    if (!user) return;
    const now = new Date().toISOString();
    const newSkill: Skill = { ...skill, id: uuid(), userId: user.id, createdAt: now, updatedAt: now };
    setSkills((prev) => {
      const updated = [...prev, newSkill];
      persistSkills(updated);
      return updated;
    });
  }, [user, persistSkills]);

  const updateSkill = useCallback((id: string, updates: Partial<Skill>) => {
    setSkills((prev) => {
      const updated = prev.map((s) =>
        s.id === id ? { ...s, ...updates, updatedAt: new Date().toISOString() } : s
      );
      persistSkills(updated);
      return updated;
    });
  }, [persistSkills]);

  const deleteSkill = useCallback((id: string) => {
    setSkills((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      persistSkills(updated);
      return updated;
    });
  }, [persistSkills]);

  // ── Certifications CRUD ────────────────────────────────────────────

  const addCertification = useCallback((cert: Omit<Certification, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    if (!user) return;
    const now = new Date().toISOString();
    const newCert: Certification = { ...cert, id: uuid(), userId: user.id, createdAt: now, updatedAt: now };
    setCertifications((prev) => {
      const updated = [...prev, newCert];
      persistCerts(updated);
      return updated;
    });
  }, [user, persistCerts]);

  const updateCertification = useCallback((id: string, updates: Partial<Certification>) => {
    setCertifications((prev) => {
      const updated = prev.map((c) =>
        c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
      );
      persistCerts(updated);
      return updated;
    });
  }, [persistCerts]);

  const deleteCertification = useCallback((id: string) => {
    setCertifications((prev) => {
      const updated = prev.filter((c) => c.id !== id);
      persistCerts(updated);
      return updated;
    });
  }, [persistCerts]);

  // ── Career Goals CRUD ──────────────────────────────────────────────

  const addGoal = useCallback((goal: Omit<CareerGoal, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    if (!user) return;
    const now = new Date().toISOString();
    const newGoal: CareerGoal = { ...goal, id: uuid(), userId: user.id, createdAt: now, updatedAt: now };
    setGoals((prev) => {
      const updated = [...prev, newGoal];
      persistGoals(updated);
      return updated;
    });
  }, [user, persistGoals]);

  const updateGoal = useCallback((id: string, updates: Partial<CareerGoal>) => {
    setGoals((prev) => {
      const updated = prev.map((g) =>
        g.id === id ? { ...g, ...updates, updatedAt: new Date().toISOString() } : g
      );
      persistGoals(updated);
      return updated;
    });
  }, [persistGoals]);

  const deleteGoal = useCallback((id: string) => {
    setGoals((prev) => {
      const updated = prev.filter((g) => g.id !== id);
      persistGoals(updated);
      return updated;
    });
  }, [persistGoals]);

  const toggleMilestone = useCallback((goalId: string, milestoneId: string) => {
    setGoals((prev) => {
      const updated = prev.map((g) => {
        if (g.id !== goalId) return g;
        const milestones = g.milestones.map((m) =>
          m.id === milestoneId
            ? { ...m, completed: !m.completed, completedAt: !m.completed ? new Date().toISOString() : null }
            : m
        );
        return { ...g, milestones, updatedAt: new Date().toISOString() };
      });
      persistGoals(updated);
      return updated;
    });
  }, [persistGoals]);

  const addMilestone = useCallback((goalId: string, title: string) => {
    setGoals((prev) => {
      const updated = prev.map((g) => {
        if (g.id !== goalId) return g;
        const milestone: Milestone = { id: uuid(), title, completed: false, completedAt: null };
        return { ...g, milestones: [...g.milestones, milestone], updatedAt: new Date().toISOString() };
      });
      persistGoals(updated);
      return updated;
    });
  }, [persistGoals]);

  const deleteMilestone = useCallback((goalId: string, milestoneId: string) => {
    setGoals((prev) => {
      const updated = prev.map((g) => {
        if (g.id !== goalId) return g;
        return { ...g, milestones: g.milestones.filter((m) => m.id !== milestoneId), updatedAt: new Date().toISOString() };
      });
      persistGoals(updated);
      return updated;
    });
  }, [persistGoals]);

  return (
    <DataContext.Provider
      value={{
        skills, addSkill, updateSkill, deleteSkill,
        certifications, addCertification, updateCertification, deleteCertification,
        goals, addGoal, updateGoal, deleteGoal, toggleMilestone, addMilestone, deleteMilestone,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

/**
 * Hook to access data state and methods.
 */
export function useData(): DataContextType {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within a DataProvider');
  return ctx;
}
